library("httr")
library("rjson")
library("PatientLevelPrediction")

package_model <- function () {
    print("#######################")
    print("Start packaging results") 
    print("#######################")

    script_name <- "validation.R"
    files <- c()
    custom_files <- list.files(path = "./custom/", all.files=TRUE, recursive=TRUE)
    custom_files <- paste("custom/", custom_files, sep="")
    files <- append(files, custom_files)
    files <- append(files, c("model.R", "settings.json", "cert"))

    zip(zipfile = "model.zip", files = files)

    print("#######################")
    print("Finished packaging results") 
    print("#######################")
}

retrieve_cert <- function() {
    print("########################")
    print("Retrieve the certificate")
    print("########################")
    settings <- fromJSON(file = "settings.json")
    url <- settings$url
    url <- paste0(url, "custom_algorithm/rand")
    print(url)
    response <- GET(url)
    verification_number <- content(response, "text")
    is_number <- !is.na(as.numeric(verification_number))
    if (!is_number) {
        return(FALSE)
    }
    file<-file("cert")
    writeLines(verification_number, file)
    close(file)
    print(verification_number)
    print("########################")
    print("Retrieved the certificate")
    print("########################")
    return(TRUE)
}

validate <- function() {
    print("################")
    print("Validate the code")
    print("#################")
    settings <- fromJSON(file = "settings.json")
    model_name <- settings$model_name
    hyper_parameters <- settings$hyper_parameters
    sample_parameters <- list()
    for (i in 1:length(hyper_parameters)) {
        parameter <- hyper_parameters[[i]]
        sample_parameters[[parameter$name]] <- parameter$default
    }
    source("model.R")
    set_method <- paste0("set", paste(toupper(substr(model_name, 1, 1)), substr(model_name, 2, nchar(model_name)), sep=""))

    modelSettings <- do.call(set_method, list())
    # modelSettings <- readRDS("modelSettings.rds")
    plpData <- loadPlpData("new_plp")
    population <- readRDS("new_pop.rds")

    indexes <- personSplitter(population, test=0.25, train = NULL, nfold=2, seed=1)

    population <- merge(population, indexes, by = 'rowId')
    colnames(population)[colnames(population)=='index'] <- 'indexes'

    settings <- list(data=plpData, minCovariateFraction=0.001,
                    normalizeData = T,
                    modelSettings = modelSettings,
                    population=population,
                    cohortId=2,
                    outcomeId=3)
    
    result <- tryCatch(do.call(fitPlp, settings), error = function(e) {
        return(FALSE)
    })
    print("########################################")
    print("The code could be successfully validated")
    print("########################################")
    return(TRUE)

}

is_valid <- validate()
if (is_valid) {
    is_cert <- retrieve_cert()
    if (!is_cert) {
        print("################################")
        print("Error retrieving the certificate")
        print("################################")
        stop()
    }
    package_model()
} else {
    print("###########################")
    print("The code could is not valid")
    print("###########################")
}
