setCustomAlgorithm <- function(function_call="setAlgorithm", ...) {
	params = list(...)
	do.call(function_call, params)	
}
